<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page session="true" %>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Dashboard</title>

    <!-- Dosis Font -->
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Dosis", sans-serif;

            background: linear-gradient(135deg, #0f172a, #111827);
            height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;

            color: #e5e7eb;
        }

        .container {
            background-color: #1f2937;
            padding: 45px;
            border-radius: 14px;
            width: 420px;
            text-align: center;

            border: 1px solid #2d3748;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);

            transition: 0.3s ease;
        }

        .container:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
        }

        h1 {
            font-size: 22px;
            margin-bottom: 10px;
            color: #f9fafb;
            font-weight: 600;
        }

        p {
            color: #cbd5e1;
            font-size: 14px;
            margin-bottom: 25px;
        }

        .btn {
            display: inline-block;
            width: 160px;
            padding: 11px;
            margin-top: 15px;

            text-decoration: none;
            font-size: 14px;
            font-weight: 600;

            border-radius: 8px;

            color: #ffffff;
            background-color: #ef4444;

            transition: 0.25s ease;
        }

        .btn:hover {
            background-color: #dc2626;
            transform: translateY(-2px);
        }

        .welcome {
            font-size: 18px;
            margin-bottom: 10px;
            color: #2ef2d2;
        }

        .divider {
            height: 1px;
            background: #374151;
            margin: 15px 0 20px;
        }
    </style>
</head>

<body>

<%
    String username = (String) session.getAttribute("username");

    if (username == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<div class="container">

    <h1>Dashboard</h1>

    <div class="divider"></div>

    <p class="welcome">Welcome, <%= username %></p>

    <p>You have successfully logged into the Employee Management System.</p>

    <a href="LogoutServlet" class="btn">Logout</a>

</div>

</body>
</html>