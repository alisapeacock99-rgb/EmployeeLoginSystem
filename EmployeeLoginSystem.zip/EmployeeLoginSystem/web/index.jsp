<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Employee Management System</title>

    <!-- Google Font: Dosis -->
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Dosis", sans-serif;
            background: linear-gradient(135deg, #0f172a, #111827);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #e5e7eb;
        }

        .container {
            background-color: #1f2937;
            padding: 45px;
            border-radius: 14px;
            width: 420px;
            text-align: center;
            border: 1px solid #2d3748;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            transition: 0.3s ease;
        }

        .container:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
        }

        h1 {
            font-size: 24px;
            margin-bottom: 12px;
            color: #f9fafb;
            font-weight: 600;
        }

        p {
            font-size: 15px;
            color: #cbd5e1;
            margin-bottom: 28px;
            line-height: 1.5;
        }

        .btn {
            display: inline-block;
            width: 160px;
            padding: 11px;
            margin: 10px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            transition: 0.25s ease;
            letter-spacing: 0.5px;
        }

        /* Register */
        .register {
            background-color: #10b981;
            color: #ffffff;
            border: 1px solid #10b981;
        }

        .register:hover {
            background-color: #059669;
            transform: translateY(-2px);
        }

        /* Login */
        .login {
            background-color: #3b82f6;
            color: #ffffff;
            border: 1px solid #3b82f6;
        }

        .login:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        footer {
            margin-top: 25px;
            font-size: 12px;
            color: #9ca3af;
        }

        .divider {
            height: 1px;
            background: #374151;
            margin: 20px 0;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Employee Management System</h1>

    <p>
        Secure employee registration and login portal for managing workforce records efficiently.
    </p>

    <div class="divider"></div>

    <a href="register.jsp" class="btn register">Register Employee</a>
    <a href="login.jsp" class="btn login">Employee Login</a>

    <footer>
        © 2026 Employee Management System
    </footer>

</div>

</body>
</html>