<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Employee Login</title>

    <!-- Dosis Font -->
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Dosis", sans-serif;
            background: linear-gradient(135deg, #0f172a, #111827);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #e5e7eb;
        }

        .container {
            background-color: #1f2937;
            padding: 40px;
            border-radius: 14px;
            width: 420px;
            border: 1px solid #2d3748;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            transition: 0.3s ease;
        }

        .container:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
        }

        h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
            color: #f9fafb;
            font-weight: 600;
        }

        .divider {
            height: 1px;
            background: #374151;
            margin: 15px 0 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 8px;
            font-size: 14px;
            color: #cbd5e1;
        }

        input {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #374151;
            background-color: #111827;
            color: #ffffff;
            outline: none;
            transition: 0.25s ease;
            font-family: "Dosis", sans-serif;
        }

        input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 8px rgba(59, 130, 246, 0.4);
        }

        .btn {
            width: 100%;
            margin-top: 20px;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            color: #ffffff;
            background-color: #3b82f6;
            font-family: "Dosis", sans-serif;
            transition: 0.25s ease;
        }

        .btn:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 15px;

            font-size: 12px;
            color: #9ca3af;
            text-decoration: none;
        }

        .back:hover {
            color: #3b82f6;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Employee Login</h1>

    <div class="divider"></div>

    <form action="LoginServlet" method="POST">

        <table>
            <tr>
                <td>Employee ID</td>
                <td><input type="text" name="employee_id" required></td>
            </tr>

            <tr>
                <td>Password</td>
                <td><input type="password" name="password" required></td>
            </tr>
        </table>

        <button type="submit" class="btn">LOGIN</button>

    </form>

    <a href="index.jsp" class="back">← Back to Dashboard</a>

</div>

</body>
</html>