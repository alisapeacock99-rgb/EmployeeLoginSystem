package database;

import java.sql.Connection;

public class TestConnection {
    public static void main(String[] args){
        Connection con = DBConnection.connect();
        
        if(con != null){
            System.out.println("Success");
        }else{
            System.out.println("Failed");
        }
    }
}
