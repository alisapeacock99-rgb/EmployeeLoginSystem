package database;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnection {

    public static Connection connect() {

        Connection con = null;

        try {

            Properties props = new Properties();

            // FIXED PATH
            FileInputStream fis = new FileInputStream(
                "C:\\Users\\alisa\\Documents\\NetBeansProjects\\EmployeeLoginSystem\\src\\db.properties"
            );

            props.load(fis);

            String url = props.getProperty("db.url");
            String user = props.getProperty("db.username");
            String password = props.getProperty("db.password");

            Class.forName("org.postgresql.Driver");

            con = DriverManager.getConnection(url, user, password);

            System.out.println("Database connected");

        } catch (Exception e) {
            System.out.println("Connection failed");
            e.printStackTrace();
        }

        return con;
    }
}