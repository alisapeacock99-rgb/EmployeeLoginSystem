package Servlet;

import database.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    @Override
    /*
    
    "doPost" - What it does: - Handles form submission securely using POST method
    - Receives form data
    - Processes it (insert/update/delete/login, etc.)
    - Sends response back to browser
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // These values come from input fields in your registration form
        String employeeId = request.getParameter("employee_id");
        String fullName = request.getParameter("full_name");
        String department = request.getParameter("department");
        String role = request.getParameter("role");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");

        Connection con = null; //connects Java to PostgreSQL/MySQL
        // PreparedStatement is used to safely execute SQL queries
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;

        try {
            con = DBConnection.connect();

            if (con == null) {
                throw new Exception("Database connection is NULL");
            }

            
            String query =
                "INSERT INTO employee(employee_id, full_name, department, role, password, phone, email) " +
                "VALUES(?,?,?,?,?,?,?)";

            ps = con.prepareStatement(query);
            ps.setString(1, employeeId);
            ps.setString(2, fullName);
            ps.setString(3, department);
            ps.setString(4, role);
            ps.setString(5, password);
            ps.setString(6, phone);
            ps.setString(7, email);

            ps.executeUpdate();

            String loginQuery =
                "INSERT INTO login(employee_id, password) VALUES(?,?)";

            ps2 = con.prepareStatement(loginQuery);
            ps2.setString(1, employeeId);
            ps2.setString(2, password);

            ps2.executeUpdate();

            response.sendRedirect("login.jsp");

        } catch (Exception e) {           
            e.printStackTrace();
            response.getWriter().println("Registration Failed: " + e.getMessage());

        } finally {
            try {
                if (ps != null) ps.close();
                if (ps2 != null) ps2.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}