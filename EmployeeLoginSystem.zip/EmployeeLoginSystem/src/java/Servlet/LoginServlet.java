
package Servlet;

import database.DBConnection;  
import java.io.IOException; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet;  
import jakarta.servlet.ServletException; 
import jakarta.servlet.annotation.WebServlet; 
import jakarta.servlet.http.HttpServlet; 
import jakarta.servlet.http.HttpServletRequest; 
import jakarta.servlet.http.HttpServletResponse; 
import jakarta.servlet.http.HttpSession; 

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        // Get form data
        String employeeId = request.getParameter("employee_id"); 
        String password = request.getParameter("password");
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try{
            // Get database connection
            con = DBConnection.connect(); 
 
            String query = "SELECT * FROM employee WHERE employee_id = ? AND password = ?"; 
 
            ps = con.prepareStatement(query);
            // Set values
            ps.setString(1, employeeId); 
            ps.setString(2, password); 
            
            // Execute query
            rs = ps.executeQuery(); 
            
            // Check login
            if(rs.next()){
                // Create session
                HttpSession session = request.getSession(); 
                // Store user data in session
                session.setAttribute( "username", rs.getString("full_name")); 
                // Redirect to dashboard
                response.sendRedirect("dashboard.jsp"); 
 
            } else {  
                response.getWriter().println( "Invalid Credentials");  
            }
            
        }catch(Exception e) { 
            e.printStackTrace(); 
        } finally {

            
            try {
                // Close ResultSet
                if (rs != null) {
                    rs.close();
                }

                // Close PreparedStatement
                if (ps != null) {
                    ps.close();
                }

                // Close Connection
                if (con != null) {
                    con.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
